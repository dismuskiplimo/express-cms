const CommentController = require("./CommentController");
const PostController = require("./PostController");
const UserController = require("./UserController");

module.exports = {
    CommentController,
    PostController,
    UserController
}