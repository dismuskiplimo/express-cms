const User = require("./user");
const Post = require("./post");
const Comment = require("./comment");

module.exports = {
    User,
    Post,
    Comment,
}